var language, weekday, month, smonth, sday, menu, settingstxt, updatedtxt, windchilltxt, windtxt, feeltxt, sunrisetxt, sunsettxt, textstringlater, humidtxt,

    warningtxt, elevationtxt, preciptxt, dewpointtxt, notxt, visibilitytxt, Fcondition;





//language="zh";// tester

     var charging = " charging";
     var discharging = " discharging";

if (language === "en") {

    weekday = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

    month = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "Nov", "December"];

    smonth = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "Nov", "December"];

    sday = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

    menu = ["Today", "Hourly", "Daily", "Settings"];

    settingstxt = ["24hr Clock", "Celsius", "Kph", "Weather Walls", "Update Weather"];

    updatedtxt = "Updated: ";

    windchilltxt = "Wind Chill: ";

    windtxt = "Wind: ";

    feeltxt = "Feels Like";

    sunrisetxt = "Sunrise: ";

    sunsettxt = "Sunset: ";

    textstringlater = "Later Today: ";

    humidtxt = "Humidity: ";

    warningtxt = "Warning ";

    elevationtxt = "Elevation: ";

    preciptxt = "Chance of rain: ";

    dewpointtxt = "Dewpoint: ";

    notxt = "No ";

    visibilitytxt = "Visibility: ";

    Fcondition = ["Tornado", "Tropical Storm", "Hurricane", "Thunderstorm", "Thunderstorm", "Snow", "Sleet", "Sleet", "Freezing Drizzle", "Drizzle", "Freezing Rain", "Showers", "Showers", "Flurries", "Snow", "Snow", "Snow", "Hail", "Sleet", "Dust", "Fog", "Haze", "Smoky", "Blustery", "Windy", "Cold", "Cloudy", "Cloudy", "Cloudy", "Cloudy", "Cloudy", "Clear", "Sunny", "Fair", "Fair", "Sleet", "Hot", "Thunderstorms", "Thunderstorms", "Thunderstorms", "Showers", "Heavy Snow", "Light Snow", "Heavy Snow", "Partly Cloudy", "Thunderstorm", "Snow", "Thunderstorm", "blank"];

}