
var refresh = 5000; 
var refreshrate = 30; 
var language = "en"; 